from django.urls import path
from store.models import Product
from  store.views import home,login,signup,cartorder,checkout,orders
from store.middlewares.auth import auth_middleware
urlpatterns=[
    path('',home.product.as_view(),name='homepage'),
    path('signup',signup.SignUp.as_view(),name='signup'),
    path('login',login.Login.as_view(),name='login'),
    path('logout',login.logout,name='logout'),
    path('cart',auth_middleware(cartorder.CartOrder.as_view()), name='cart'),
    path('checkout',checkout.Checkout.as_view(), name='checkout'),
    path('orders',auth_middleware(orders.PlaceOrder.as_view()), name='checkout'),
]