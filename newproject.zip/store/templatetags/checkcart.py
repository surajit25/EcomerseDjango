from django import template
from store.models.product import Product

register = template.Library();

@register.filter(name='is_in_cart')

#this is for making cart value send true or false.
#we have made a templatetags module for making filter function.
#we have register with that method and we can use it on to the project by {% load templatetag_name%}
def is_in_cart(id,cart):
    v=cart.keys()
    for x in v:
        if str(id)==str(x):
            return True;
    return False;


@register.filter(name='count_quantity')

def count_quantity(product_id,cart):
    key=cart.keys()
    for y in key:
       if str(product_id)==str(y):
           return cart.get(y)
    return 0;

@register.filter(name='total_price')

def total_price(cart):
    key=list(cart.keys())
    value=list(cart.values())
    pro=Product.find_product_by_id(key)
    sum=0
    i=0;
    for x in pro:
        sum+=int(x.price)*int(value[i]);
        i+=1
    return sum;

@register.filter(name='display_quantity')

def display_quantity(cart,id):
    key=cart.keys()
    for x in key:
        if(str(x)==str(id)):
            return cart.get(x);


@register.filter(name='total_per_product')

def total_per_product(number1,number2):
    return int(number1)*int(number2);

@register.filter(name='total_in_cart')

def total_in_cart(cart):
    try:
        value = list(cart.values());
        sum = 0;
        for x in value:
            sum += int(x);
        return sum;
    except:
        return 0;
