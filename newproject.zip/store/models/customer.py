from django.db import models

class Customer(models.Model):
    first_name = models.CharField(max_length=30,default='')
    last_name = models.CharField(max_length=30,default='')
    email = models.EmailField(max_length=40,default='')
    phone = models.CharField(max_length=10,default='')
    user_name = models.CharField(max_length=20,default='')
    password = models.CharField(max_length=100,default='')

    @staticmethod
    def get_customer_details(email):
        try:
            return Customer.objects.get(email=email)
        except:
            return False
