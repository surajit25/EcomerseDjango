from django.db import models
from .category import Category

class Product(models.Model):
    name = models.CharField(max_length=30,default='')
    price = models.IntegerField(default='')
    description = models.TextField(max_length=200, default='')
    category = models.ForeignKey(Category,on_delete=models.CASCADE,default=1)
    image = models.ImageField(upload_to='pics/product',default='')

    @staticmethod
    def find_product_by_id(id):
        return Product.objects.filter(id__in=id) #this is  the id__in for passing the whole list