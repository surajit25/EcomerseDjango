from django.shortcuts import redirect
def auth_middleware(get_response):
    # One-time configuration and initialization.

    def middleware(request):
        customer=request.session.get('customer_id')
        urlPath=request.META['PATH_INFO']
        if not customer:
            return redirect(f'login?return_url={urlPath}')
        response = get_response(request)

        return response
    return middleware
