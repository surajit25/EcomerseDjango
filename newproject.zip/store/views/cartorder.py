from django.shortcuts import render,redirect
from django.views import View
from store.models.product import Product
from store.models.customer import Customer

class CartOrder(View):

    def get(self,request):
       cart =list( request.session.get('cart').keys())

       if cart:
           product=Product.find_product_by_id(cart)
           return render(request,'orders.html',{'checkcart':product})
       else:
         nocart="There is no cart value"
         return render(request,'orders.html',{'nocart':nocart})







