from django.shortcuts import render,redirect
from django.views import View

from store.models import Category
from store.models import Product


class product(View):
    def get(self,request):
        product = None
        category = Category.objects.all();
        categoryId = request.GET.get('category')


        if categoryId == str(1) or categoryId == None:
            product = Product.objects.all();
        else:
            product = Product.objects.filter(category=categoryId);
        data = {}
        data['product'] = product
        data['categories'] = category
        customer_id = request.session.get('customer_id')
        customer_username = request.session.get('username')
        data['customer_id'] = customer_id
        data['customer_username'] = customer_username

        return render(request, 'index.html', data)


    def post(self,request):
        product_id=request.POST.get('product_id');
        cart = request.session.get('cart')
        reduce = request.POST.get('remove')
        print(reduce)
        if cart:
            quantity =cart.get(product_id)
            if quantity:
                if reduce:
                    if quantity<=1:
                        cart.pop(product_id)
                    else:
                        cart[product_id]=quantity-1
                else:
                    cart[product_id]=quantity+1
            else:
                cart[product_id]=1
        else:
            cart={};
            cart[product_id]=1

        request.session['cart']=cart
        return redirect('homepage')



