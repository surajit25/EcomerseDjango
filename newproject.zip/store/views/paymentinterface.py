from django.views import View
from django.shortcuts import render,redirect
from store.models.address import Address
class SaveAddress(View):
    def get(self,request):
        pass;
    def post(self,request):
        address1=request.POST.get('address1')
        address2=request.POST.get('address2')
        email=request.POST.get('email')
        city=request.POST.get('city')
        state=request.POST.get('state')
        zip=request.POST.get('zip')

        addresssave=Address(address1=address1,address2=address2,email=email,city=city,state=state,zip=zip)
        addresssave.save()
        message='Address save successfully'
        return render(request,'payment.html',{'success':message})